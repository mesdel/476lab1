﻿Low poly soccer ball model for games, educational, visualization and other purposes. 
Made with Maya 7, clean topology, no N-gons and triangles, only quads.
UV mapped and fully textured, unwrapping done with overlapping.
Maya 7 (.ma, .mb), OBJ (.obj with .mtl), 3ds Max 2009 (.max) and Autodesk FBX (.fbx) format included. FBX and OBJ are directly exported from Maya.
Polygons: 360 quads
Vertices: 323
Model is mapped on single 512×512 pixels texture map. Two formats included: .tiff with LZW compression and .jpg. 




